THIS ARCHIVE CONTAINS AN OLD PLUGIN VERSION! 

Download latest version here: 
https://github.com/malihu/malihu-custom-scrollbar-plugin/archive/master.zip

Release archive: 
https://github.com/malihu/malihu-custom-scrollbar-plugin/releases

Plugin homepage and documentation: 
http://manos.malihu.gr/jquery-custom-content-scroller/